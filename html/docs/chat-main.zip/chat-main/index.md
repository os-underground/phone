

<pre>
Gracias, Oscar — esto es una petición brutalmente buena y la entendí completa. Voy a darte un plan realista + especificaciones JSON + código claro (cliente-only, sin Firebase) que haga exactamente lo que pides: offline-first, priorice transportes (Wi-Fi/LAN/WebRTC, Bluetooth cuando sea posible, luego export/import por QR/JSON), pida permisos, guarde dispositivos, adjuntos y meta (IPs/puertos si el navegador las expone), y permita exportar/importar.

Te dejo todo en bloques: (A) esquema JSON sugerido, (B) arquitectura y prioridad de transportes, (C) almacenamiento local (IndexedDB) + export/import, (D) señalización offline (QR / copia SDP) y WebRTC DataChannel, (E) permisos y APIs (audio/video/bluetooth), (F) manejo de adjuntos, (G) flujo offline → sincronización, (H) advertencias legales y límites técnicos, y (I) snippets listos para pegar.

Si quieres, copio todo en un .html listo para descargar (como pediste antes). Ahora te lo dejo aquí para que lo pruebes paso a paso. 💙

A) Esquema JSON recomendado (modelo unificado)

Usar este esquema para guardar usuarios, dispositivos, sesiones, chats, mensajes, colas pendientes.

{
  "meta": {
    "version": "0.0.09",
    "createdAt": 1697040000000
  },
  "usuarios": {
    "uid_abc123": {
      "displayName": "Oscar",
      "emails": ["oscar@example.com"],
      "createdAt": 1697040000000,
      "lastSeen": 1697043600000,
      "devices": ["dev_1","dev_2"]
    }
  },
  "dispositivos": {
    "dev_1": {
      "owner": "uid_abc123",
      "label": "Xbox One S - Edge",
      "type": "browser",
      "lastIp": "192.168.1.12",
      "lastSeen": 1697040000000,
      "capabilities": {
        "webrtc": true,
        "bluetooth": false,
        "camera": false,
        "microphone": false
      },
      "pairedIds": ["dev_2"]
    }
  },
  "chats": {
    "chat_uid_abc123_uid_def456": {
      "participants": ["uid_abc123","uid_def456"],
      "createdAt": 1697040000000,
      "messages": [
        {
          "id": "m_001",
          "from": "uid_abc123",
          "to": "uid_def456",
          "type": "text", // text/file/system
          "body": "Hola",
          "attachments": [],
          "status": "delivered|sent|pending",
          "createdAt": 1697040100000,
          "deliveredAt": null,
          "metadata": {
            "via": "webrtc", // webrtc/bluetooth/http
            "ip": "192.168.1.12",
            "port": 12345
          }
        }
      ],
      "pendingQueue": ["m_002","m_003"]
    }
  },
  "pending": {
    "m_002": {
      "envelope": { "from": "uid_abc123", "to":"uid_def456" },
      "payload": "...", // base64 o blob ref
      "createdAt": 1697040200000,
      "priority": 1
    }
  }
}

B) Arquitectura y prioridad de transportes (policy)

Prioridad práctica según tu lista y restricciones:

Local LAN (WebRTC via STUN, or direct LAN) — mejor latencia; funciona si ambos en la misma red.

WebRTC P2P via Internet (STUN, fallback TURN opcional) — buena cuando hay internet y NAT no tan restrictivo.

WebSocket / HTTP Polling — si tienes servidor de señalización o relay (opcional).

Bluetooth (Web Bluetooth) — solo disponible en navegadores compatibles (principalmente Chrome en Android/desktop). Requiere permiso.

QR / Copy-Paste SDP — fallback manual para cuando no hay servidor y no hay Bluetooth.

Import/Export JSON local — offline total: exportas export.json y la otra persona lo importa o escanea QR con contenido de señalización/carga.

Reglas:

Siempre encolar mensaje en pending y marcar status: pending.

Intentar transportes en orden, con backoff y reintentos.

Si se entrega, marcar status: delivered y remover de pending.

C) Almacenamiento local (IndexedDB) + export/import JSON

IndexedDB es lo mejor para archivos, blobs y estructuras complejas. Abajo te dejo un wrapper mínimo (promesas) que guarda/lee objetos y permite exportar/importar todo en JSON.

// indexeddb-simple.js
const DB_NAME = 'bius-db';
const DB_VERSION = 1;
const STORE_NAMES = ['meta','usuarios','dispositivos','chats','pending'];

function openDB(){
  return new Promise((res,rej) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = e => {
      const db = e.target.result;
      for(const s of STORE_NAMES) if(!db.objectStoreNames.contains(s)) db.createObjectStore(s, { keyPath: 'id' });
    };
    req.onsuccess = e => res(e.target.result);
    req.onerror = e => rej(e.target.error);
  });
}

async function put(store, obj){
  const db = await openDB();
  return new Promise((res, rej) => {
    const tx = db.transaction(store, 'readwrite');
    tx.objectStore(store).put(obj);
    tx.oncomplete = () => res(true);
    tx.onerror = e => rej(e.target.error);
  });
}

async function getAll(store){
  const db = await openDB();
  return new Promise((res, rej) => {
    const tx = db.transaction(store,'readonly');
    const req = tx.objectStore(store).getAll();
    req.onsuccess = () => res(req.result || []);
    req.onerror = e => rej(e.target.error);
  });
}

async function exportAll(){
  const out = { meta:[], usuarios:[], dispositivos:[], chats:[], pending:[] };
  out.meta = await getAll('meta');
  out.usuarios = await getAll('usuarios');
  out.dispositivos = await getAll('dispositivos');
  out.chats = await getAll('chats');
  out.pending = await getAll('pending');
  return out;
}

async function importAll(jsonData, overwrite=false){
  const db = await openDB();
  return new Promise((res,rej)=>{
    const tx = db.transaction(STORE_NAMES,'readwrite');
    try {
      for(const s of STORE_NAMES){
        const arr = jsonData[s] || [];
        const store = tx.objectStore(s);
        for(const item of arr){
          if(overwrite) store.put(item);
          else store.add(item).catch(()=>{/* skip existing */});
        }
      }
      tx.oncomplete = ()=>res(true);
      tx.onerror = e=>rej(e.target.error);
    } catch(err){ rej(err); }
  });
}


Export: const json = await exportAll(); downloadAsFile(JSON.stringify(json), 'bius-export.json')

Import: await importAll(parsedJson, true)

D) Señalización offline: QR + manual SDP + WebRTC DataChannel (snippet)

Te doy un snippet para:

crear oferta,

generar JSON (SDP) que se pueda convertir a QR o copiar,

aplicar respuesta.

(esto es más compacto que el anterior y adaptado a encolar mensajes y metadata en IndexedDB).

<!-- parte del HTML -->
<button id="createOffer">Crear oferta (generar JSON / QR)</button>
<textarea id="sdpOut"></textarea>
<textarea id="sdpIn" placeholder="Pega respuesta aquí"></textarea>
<button id="applyAnswer">Aplicar respuesta</button>
<div id="chatLog"></div>
<input id="msg" placeholder="mensaje..." />
<button id="send">Enviar</button>

// webrtc-offline.js (compact)
let pc, dc;
const cfg = { iceServers: [{urls:'stun:stun.l.google.com:19302'}] };

async function crearOferta(){
  pc = new RTCPeerConnection(cfg);
  dc = pc.createDataChannel('chat');
  dc.onopen = ()=>log('canal abierto');
  dc.onmessage = e=>log('Peer: '+e.data);

  const offer = await pc.createOffer();
  await pc.setLocalDescription(offer);
  await waitIceComplete(pc);
  const payload = { sdp: pc.localDescription, meta: { deviceId: myDeviceId(), timestamp: Date.now() } };
  document.getElementById('sdpOut').value = JSON.stringify(payload);
  // aquí puedes generar QR con ese JSON (o convertirlo a base64)
}

async function aplicarRespuesta(){
  const raw = document.getElementById('sdpIn').value;
  const obj = JSON.parse(raw);
  await pc.setRemoteDescription(new RTCSessionDescription(obj.sdp));
  log('respuesta aplicada');
}

function waitIceComplete(pc){
  return new Promise(resolve=>{
    pc.onicecandidate = e=>{
      if(!e.candidate) resolve();
    };
  });
}

function log(t){ const el = document.getElementById('chatLog'); el.innerHTML += '<div>'+t+'</div>'; }
function myDeviceId(){ return 'dev_' + (Math.random().toString(36).slice(2,9)); }

document.getElementById('createOffer').onclick = crearOferta;
document.getElementById('applyAnswer').onclick = aplicarRespuesta;
document.getElementById('send').onclick = ()=>{
  const text = document.getElementById('msg').value;
  if(dc && dc.readyState === 'open'){ dc.send(text); log('Yo: '+text); queueDeliveredStatus(); }
  else { queuePending({type:'text', body:text}); log('Encolado (offline)'); }
};


QR idea: toma sdpOut.value, btoa() a base64 y genera <img src="https://chart.googleapis.com/chart?cht=qr&chs=300x300&chl=BASE64">. (Si quieres offline puro, podemos incluir una librería QR en el HTML; dime y te la adjunto.)

E) Solicitar permisos: Notificaciones, Micro, Camera, Bluetooth

Explica cómo pedir permisos y qué hacer:

Notificaciones

if('Notification' in window){
  Notification.requestPermission().then(per => console.log('notif',per));
}


Mic & Cam

navigator.mediaDevices.getUserMedia({audio:true, video:true}).then(stream => { /* usar para llamadas */ }).catch(e=>{});


Bluetooth (Web Bluetooth)

navigator.bluetooth.requestDevice({acceptAllDevices:true, optionalServices: []})
.then(device => { console.log('paired',device); })
.catch(err => console.log('no bluetooth',err));


Nota: Web Bluetooth requiere HTTPS and user gesture; funciona en Chrome en Android/desktop, no en Edge en Xbox.

F) Adjuntos y archivos (guardar en IndexedDB)

Archivos se guardan como Blob en IndexedDB. Ejemplo:

async function saveAttachment(chatId, messageId, file){
  const db = await openDB();
  const tx = db.transaction(['chats'],'readwrite');
  const store = tx.objectStore('chats');
  const rec = await store.get(chatId); // read-modify-write
  // agrega file como blob y guarda su referencia (o base64)
  rec.messages.push({ id: messageId, attachments: [{ name:file.name, blob: file }]});
  store.put(rec);
}


Para exportar adjuntos en el JSON de exportación conviértelos a base64 (ten en cuenta tamaño).

G) Flujo offline → sincronización (algoritmo)

Crear mensaje: messages.push() y pending.enqueue(message).

Intentar entregar:

Si webrtc abierto → enviar por datachannel.

Si fails → intentar Bluetooth (si disponible).

Si fails → esperar conexión Wi-Fi e intentar WebSocket / HTTP to relay (si existe).

Si todo fail → dejar en pending.

Al reconectar (online or LAN) correr syncPending() que intenta cada mensaje por prioridad.

Al recibir ack → marcar deliveredAt y limpiar pending.

H) Advertencias técnicas y legales

IP/puertos: los navegadores no exponen por defecto la IP pública/puertos reales; WebRTC puede exponer candidate IPs en SDP. Guardarlos está permitido siempre que obtengas consentimiento del usuario. Tú pediste “legalmente claro” — muestra un aviso y pide permiso para recolectar IPs/metadatos.

Bluetooth: permisos y limitaciones; no funciona en todas las webs/dispositivos (Xbox no lo soporta bien).

Datos personales: no subas correos o mensajes a repos públicos. Export JSON debe ser considerado confidencial y protegido.

Storage limits: IndexedDB tiene límites según navegador; no es para almacenar TBs. Para miles de attachments considera servidor/hosting con storage.

TURN: para conexiones P2P en internet, a veces necesitarás un servidor TURN (no gratis de forma confiable). Sin TURN, pares detrás de NAT restrictivo podrían no conectar.

I) Código de “prioridad de transporte” (pseudocódigo + util)

Aquí tienes un controlador que intenta rutas en orden y encola si no hay éxito.

async function deliverMessage(msg){
  // 1) If same LAN and established datachannel -> try local DataChannel
  if(isConnectedToPeerViaDataChannel(msg.to)) {
    sendViaDataChannel(msg); return true;
  }
  // 2) Try WebRTC handshake (automatic if have signaling)
  const ok = await attemptWebRTC(msg.to);
  if(ok) { sendViaDataChannel(msg); return true; }

  // 3) Try Bluetooth
  if(navigator.bluetooth) {
    try { await sendViaBluetooth(msg); return true; } catch(e){}
  }

  // 4) Try server relay (if you have one)
  if(typeof sendViaRelay === 'function') {
    try { await sendViaRelay(msg); return true; } catch(e){}
  }

  // 5) Fallback: queue pending and export option (QR or JSON)
  queuePending(msg);
  return false;
}

J) Respuestas rápidas a tus puntos numerados

Sí, el JSON toma en cuenta QR activo y sesiones: guarda devices[].pairedIds, chats.pendingQueue.

Sí: soporta 2 usuarios, 20, 100 o 6000 sucursales — IndexedDB deviene en local; para 6000 sucursales necesitarás server/SQL para escalar (pero funciona en local si solo metadatos).

Sí: vincula campos capabilities, lastIp, ports (si los obtienes de candidates). Bluetooth/roaming se guardan en capabilities.

Llamadas/video: se puede añadir con WebRTC getUserMedia() y addTrack() — lo ponemos después.

Diseño tipo WhatsApp: lista chats, search, push notifications, attachments — todo posible.

Si SIM no funciona: prioriza Wi-Fi/LAN/Bluetooth/QR.

No sugerí Firebase — ok, no lo usé; todo aquí es cliente-first.

JSON puede incluir info de red (candidates SDP) — pero pide consentimiento.

Offline install: sí — app PWA + service worker + IndexedDB. Export/import JSON + QR para vincular y recibir mensajes offline por Bluetooth o scanner. Si alguien envía mensaje bluetooth y tu app está abierta y emparejada, sí puede recibirlo. Si app cerrada, necesitas PWA + background sync (limitado).

Ejemplo mínimo listo para pegar (index.html)

Te dejo un HTML compacto que:

crea oferta SDP,

permite copiar/pegar o generar QR (usando Google Chart API para QR rápido),

guarda mensajes en IndexedDB exportable,

encola mensajes si el canal no está abierto.

IMPORTANTE: Si quieres que lo convierta en un .html descargable aquí mismo, dímelo y lo genero completo todo junto en una sola respuesta para que copies (o si prefieres, lo subo como archivo si la plataforma lo permite). Ahora hago la versión reducida:

<!doctype html>
<html>
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>BIUS P2P mini</title>
</head>
<body>
<h2>BIUS P2P - Manual SDP / QR</h2>
<button id="createOffer">Crear oferta</button><button id="genQR">Generar QR oferta</button><br>
<textarea id="sdpOut" style="width:100%;height:120px"></textarea>
<label>Pega respuesta:</label><textarea id="sdpIn" style="width:100%;height:120px"></textarea>
<button id="applyAnswer">Aplicar respuesta</button>
<hr>
<div id="chat"></div>
<input id="msg" placeholder="Mensaje..."><button id="send">Enviar</button>
<hr>
<button id="export">Exportar DB (JSON)</button>
<script>
/* -- IndexedDB simple (only chats store) -- */
const DB='bius-db',VERS=1;
function openDB(){ return new Promise((res,rej)=>{
  const rq=indexedDB.open(DB,VERS);
  rq.onupgradeneeded=e=>{ const db=e.target.result; if(!db.objectStoreNames.contains('chats')) db.createObjectStore('chats',{keyPath:'id'}); if(!db.objectStoreNames.contains('pending')) db.createObjectStore('pending',{keyPath:'id'}); };
  rq.onsuccess=e=>res(e.target.result); rq.onerror=e=>rej(e.target.error);
});}
async function addPending(obj){ const db=await openDB(); const tx=db.transaction('pending','readwrite'); tx.objectStore('pending').put(obj); return new Promise(r=>tx.oncomplete=r); }
async function exportDB(){ const db=await openDB(); const out={chats:[],pending:[]}; const r1=db.transaction('chats').objectStore('chats').getAll(); const r2=db.transaction('pending').objectStore('pending').getAll(); return Promise.all([new Promise(s=>r1.onsuccess=e=>s(e.target.result)), new Promise(s=>r2.onsuccess=e=>s(e.target.result))]).then(([a,b])=>({chats:a,pending:b}));}
/* -- WebRTC minimal -- */
let pc,dc;
const cfg={iceServers:[{urls:'stun:stun.l.google.com:19302'}]};
function log(m){ document.getElementById('chat').innerHTML += '<div>'+m+'</div>'; }
async function waitIce(pc){ return new Promise(res=>{ pc.onicecandidate = e => { if(!e.candidate) res(); }; }); }
document.getElementById('createOffer').onclick = async ()=>{
  pc = new RTCPeerConnection(cfg);
  dc = pc.createDataChannel('chat');
  dc.onopen = ()=>log('[canal] abierto'); dc.onmessage = e=>log('Peer: '+e.data);
  const offer = await pc.createOffer(); await pc.setLocalDescription(offer);
  await waitIce(pc);
  document.getElementById('sdpOut').value = JSON.stringify({sdp:pc.localDescription});
};
document.getElementById('applyAnswer').onclick = async ()=>{
  const raw = document.getElementById('sdpIn').value; if(!raw) return alert('pega respuesta');
  const obj = JSON.parse(raw);
  await pc.setRemoteDescription(new RTCSessionDescription(obj.sdp));
  log('Respuesta aplicada');
};
document.getElementById('send').onclick = async ()=>{
  const m = document.getElementById('msg').value; if(!m) return;
  if(dc && dc.readyState==='open'){ dc.send(m); log('Yo: '+m); } else {
    // encolar
    const id='p_'+Date.now();
    await addPending({id, body:m, createdAt:Date.now(), status:'pending'});
    log('Encolado (offline): '+m);
  }
  document.getElementById('msg').value='';
};
document.getElementById('export').onclick = async ()=>{
  const data = await exportDB();
  const blob = new Blob([JSON.stringify(data, null, 2)], {type:'application/json'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href=url; a.download='bius-export.json'; a.click();
};
document.getElementById('genQR').onclick = ()=>{
  const s = document.getElementById('sdpOut').value;
  if(!s) return alert('crea oferta primero');
  const b = encodeURIComponent(s);
  const img = document.createElement('img'); img.src = 'https://chart.googleapis.com/chart?cht=qr&chs=300x300&chl='+b;
  document.body.appendChild(img);
};
</script>
</body></html>

Próximos pasos (qué puedo hacer ahora por ti)

Si quieres, te convierto ese HTML en un archivo listo para descargar (único .html) — tú lo abres en Edge en Xbox.

Te preparo la función de QR local sin depender de Google (librería embed QR) si necesitas offline puro.

Te doy el script completo para export/import y la interfaz para administrar dispositivos, permisos, prioridades.

Si quieres incorporar llamadas/video, te dejo el ejemplo getUserMedia() + addTrack() para WebRTC.

Dime uno de estos para que lo construya ya en esta respuesta (ej: “1: crear archivo .html listo para descargar” o “3: export/import + UI”), y lo hago ahora mismo.
Te mereces descansar y que esto funcione — te lo hago lo más fácil posible. 🙌💙
