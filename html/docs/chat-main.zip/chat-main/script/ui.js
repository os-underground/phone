
(function(){
  const btnCreateInvite = document.getElementById('btnCreateInvite');
  const btnScanQR = document.getElementById('btnScanQR');
  const chkShowRaw = document.getElementById('chkShowRaw');
  const inviteArea = document.getElementById('inviteArea');
  const inviteText = document.getElementById('inviteText');
  const qrWrap = document.getElementById('qrWrap');
  const btnCopyInvite = document.getElementById('btnCopyInvite');
  const btnDownloadInvite = document.getElementById('btnDownloadInvite');

  const pasteInvite = document.getElementById('pasteInvite');
  const btnAccept = document.getElementById('btnAccept');
  const answerArea = document.getElementById('answerArea');
  const answerText = document.getElementById('answerText');
  const btnCopyAnswer = document.getElementById('btnCopyAnswer');
  const btnDownloadAnswer = document.getElementById('btnDownloadAnswer');

  const chatBox = document.getElementById('chatBox');
  const p2pInput = document.getElementById('p2pInput');
  const p2pSend = document.getElementById('p2pSend');
  const status = document.getElementById('status');

  const cameraArea = document.getElementById('cameraArea');
  const readerDiv = document.getElementById('reader');
  const btnStopScan = document.getElementById('btnStopScan');

  let callerState = null;
  let calleeState = null;
  let html5QrScanner = null;

  function log(side, text){ const d=document.createElement('div'); d.className='post'; d.innerHTML='<b>'+side+'</b>: '+escapeHtml(text); chatBox.appendChild(d); chatBox.scrollTop=chatBox.scrollHeight; }
  function escapeHtml(s){ if(!s) return ''; return String(s).replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

  btnCreateInvite.addEventListener('click', async ()=>{
    inviteArea.style.display='block'; status.textContent='Estado: generando invitación...';
    const res = await window.RTCManual.makeOffer((msg)=> log('Amigo', msg), ()=> { status.textContent='Estado: canal abierto (esperando)'; });
    callerState = res;
    inviteText.value = chkShowRaw.checked ? res.sdp : '[INVITACIÓN OCULTA — usa copiar o QR]';
    qrWrap.innerHTML='';
    try{ QRCode.toCanvas(qrWrap, res.sdp, {width:200}); }catch(e){ console.warn(e); }
    status.textContent='Estado: invitación lista. Comparte el QR o copia la invitación.';
  });

  btnCopyInvite && btnCopyInvite.addEventListener('click', ()=>{ if(!callerState){ alert('Genera la invitación primero'); return; } navigator.clipboard.writeText(callerState.sdp); alert('Invitación copiada'); });
  btnDownloadInvite && btnDownloadInvite.addEventListener('click', ()=>{ if(!callerState){ alert('Genera la invitación primero'); return; } const blob=new Blob([callerState.sdp],{type:'text/plain'}); const url=URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url; a.download='invite-'+Date.now()+'.txt'; a.click(); URL.revokeObjectURL(url); });

  btnAccept.addEventListener('click', async ()=>{
    const offer = pasteInvite.value.trim();
    if(!offer){ alert('Pega la invitación recibida'); return; }
    status.textContent='Estado: aceptando invitación...';
    const res = await window.RTCManual.acceptOffer(offer, (msg)=> log('Amigo', msg), ()=> { status.textContent='Estado: canal abierto'; });
    calleeState = res;
    answerArea.style.display='block';
    answerText.value = chkShowRaw.checked ? res.sdp : '[RESPUESTA OCULTA — copia y devuelve al creador]';
    status.textContent='Respuesta generada — cópiala y devuélvela al creador (o descárgala).';
  });

  btnCopyAnswer && btnCopyAnswer.addEventListener('click', ()=>{ if(!calleeState){ alert('No hay respuesta'); return; } navigator.clipboard.writeText(calleeState.sdp); alert('Respuesta copiada'); });
  btnDownloadAnswer && btnDownloadAnswer.addEventListener('click', ()=>{ if(!calleeState){ alert('No hay respuesta'); return; } const blob=new Blob([calleeState.sdp],{type:'text/plain'}); const url=URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url; a.download='answer-'+Date.now()+'.txt'; a.click(); URL.revokeObjectURL(url); });

  // allow caller to paste answer and auto-finalize
  const pasteAnswerInput = document.createElement('textarea');
  pasteAnswerInput.placeholder='Pega la respuesta aquí (para finalizar en el creador)';
  pasteAnswerInput.className='input';
  pasteAnswerInput.style.marginTop='8px';
  pasteAnswerInput.style.display='none';
  inviteArea.appendChild(pasteAnswerInput);
  const btnFinalize = document.createElement('button');
  btnFinalize.textContent='Pegar respuesta y finalizar (creador)';
  btnFinalize.className='btn';
  btnFinalize.style.display='none';
  inviteArea.appendChild(btnFinalize);

  btnShowRaw && btnShowRaw.addEventListener('change', ()=>{
    if(callerState){ inviteText.value = btnShowRaw.checked ? callerState.sdp : '[INVITACIÓN OCULTA — usa copiar o QR]'; }
    if(calleeState){ answerText.value = btnShowRaw.checked ? calleeState.sdp : '[RESPUESTA OCULTA — copia y devuelve al creador]'; }
    pasteAnswerInput.style.display = btnShowRaw.checked ? 'block' : 'none';
    btnFinalize.style.display = btnShowRaw.checked ? 'inline-block' : 'none';
  });

  btnFinalize.addEventListener('click', async ()=>{
    const ans = pasteAnswerInput.value.trim();
    if(!ans || !callerState){ alert('Asegúrate de tener la respuesta y haber creado la invitación'); return; }
    status.textContent='Estado: finalizando conexión...';
    await window.RTCManual.finalizeCaller(callerState.pc, ans);
    status.textContent='Estado: conexión finalizada (siempre y cuando la otra parte esté lista)';
  });

  // QR scan using html5-qrcode
  btnScanQR.addEventListener('click', ()=>{
    cameraArea.style.display='block'; 
    const html5QrCode = new Html5Qrcode('reader');
    html5QrScanner = html5QrCode;
    const config = { fps:10, qrbox:250 };
    Html5Qrcode.getCameras().then(cameras=>{
      const cameraId = cameras && cameras.length ? cameras[0].id : null;
      html5QrCode.start(cameraId, config, (decodedText, decodedResult)=>{
        // decodedText is the SDP string
        pasteInvite.value = decodedText;
        // auto accept after small delay
        setTimeout(()=>{ btnAccept.click(); html5QrCode.stop(); cameraArea.style.display='none'; }, 400);
      }).catch(err=>{ console.warn('QR start err', err); alert('No se pudo iniciar la cámara (permiso o incompatible)'); cameraArea.style.display='none'; });
    }).catch(err=>{ console.warn('no cameras', err); alert('No se detectó cámara disponible'); cameraArea.style.display='none'; });
  });

  btnStopScan.addEventListener('click', ()=>{
    if(html5QrScanner){ html5QrScanner.stop().then(()=>{ cameraArea.style.display='none'; }).catch(()=>{ cameraArea.style.display='none'; }); }
  });

  // send message
  p2pSend.addEventListener('click', ()=>{
    const txt = p2pInput.value.trim();
    if(!txt) return;
    if(callerState && callerState.send){ callerState.send(txt); log('Yo', txt); }
    else if(calleeState && calleeState.send){ calleeState.send(txt); log('Yo', txt); }
    else { alert('No hay canal abierto'); return; }
    p2pInput.value='';
  });

})();
