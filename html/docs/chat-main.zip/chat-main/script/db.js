




// db.js — minimal IndexedDB wrapper (no dependencia)
export function openDB(name='app-db', version=1) {
  return new Promise((res, rej) => {
    const req = indexedDB.open(name, version);
    req.onupgradeneeded = (e) => {
      const db = e.target.result;
      if (!db.objectStoreNames.contains('profiles')) db.createObjectStore('profiles', { keyPath: 'id' });
      if (!db.objectStoreNames.contains('messages')) db.createObjectStore('messages', { keyPath: 'id' });
      if (!db.objectStoreNames.contains('meta')) db.createObjectStore('meta', { keyPath: 'key' });
    };
    req.onsuccess = () => res(req.result);
    req.onerror = () => rej(req.error);
  });
}

export async function put(storeName, obj) {
  const db = await openDB();
  return new Promise((res, rej) => {
    const tx = db.transaction(storeName, 'readwrite');
    tx.objectStore(storeName).put(obj);
    tx.oncomplete = () => res(true);
    tx.onerror = () => rej(tx.error);
  });
}

export async function get(storeName, key) {
  const db = await openDB();
  return new Promise((res, rej) => {
    const tx = db.transaction(storeName, 'readonly');
    const req = tx.objectStore(storeName).get(key);
    req.onsuccess = () => res(req.result);
    req.onerror = () => rej(req.error);
  });
}

export async function getAll(storeName) {
  const db = await openDB();
  return new Promise((res, rej) => {
    const tx = db.transaction(storeName, 'readonly');
    const req = tx.objectStore(storeName).getAll();
    req.onsuccess = () => res(req.result);
    req.onerror = () => rej(req.error);
  });
}

export async function deleteKey(storeName, key) {
  const db = await openDB();
  return new Promise((res, rej) => {
    const tx = db.transaction(storeName, 'readwrite');
    tx.objectStore(storeName).delete(key);
    tx.oncomplete = () => res(true);
    tx.onerror = () => rej(tx.error);
  });
}

/*
2) Generar identidad en cliente (Web Crypto)
Archivo crypto-keys.js:
*/

// crypto-keys.js — ECDH keypair exportable (public for sharing)
export async function generateKeyPair() {
  const keyPair = await crypto.subtle.generateKey(
    { name: 'ECDSA', namedCurve: 'P-256' },
    true,
    ['sign', 'verify']
  );
  const pub = await crypto.subtle.exportKey('spki', keyPair.publicKey);
  const priv = await crypto.subtle.exportKey('pkcs8', keyPair.privateKey);
  // convert to base64 for easy storage
  return {
    publicKey: arrayBufferToBase64(pub),
    privateKey: arrayBufferToBase64(priv),
  };
}

function arrayBufferToBase64(buffer) {
  const bytes = new Uint8Array(buffer);
  let binary = '';
  for (let i=0;i<bytes.byteLength;i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary);
}

/*
Guarda privateKey en IndexedDB; publicKey lo compartes.

3) Export / Import de perfil (JSON)

En tu UI, permite botón “Exportar perfil” y “Importar perfil”:
*/

// exportProfile.js
import { get, put } from './db.js';

export async function exportProfile(id) {
  const profile = await get('profiles', id);
  const blob = new Blob([JSON.stringify(profile)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `profile-${id}.json`;
  a.click();
  URL.revokeObjectURL(url);
}

export async function importProfileFile(file) {
  const text = await file.text();
  const obj = JSON.parse(text);
  // show confirmation modal with summary before saving
  await put('profiles', obj);
}


/*
Importante: siempre mostrar preview + checkbox de consentimiento antes de guardar.

4) Compartir por QR (pegar link JSON o encode)

Puedes usar una librería QR como qrcode.min.js (pega el script en HTML). Ejemplo sencillo:
*/

<!-- en tu HTML -->
<script src="https://cdn.jsdelivr.net/npm/qrcode@1.5.1/build/qrcode.min.js"></script>
<div id="qr"></div>
<script>
  const profile = { id: 'alice123', name: 'Alice', publicKey: 'AAA...' };
  // Encode JSON compactamente (cuidado con tamaño de imagen)
  const data = JSON.stringify(profile);
  QRCode.toCanvas(document.getElementById('qr'), data, function (error) {
    if (error) console.error(error);
  });
</script>

/*
Si JSON es muy grande, mejor exportar archivo y compartir archivo en vez de QR.

5) WebRTC manual signaling (copy/paste offers)

Esto evita servidor de señalización: dos usuarios copian/pegan las ofertas SDP.
*/


// rtc-manual.js (esquema)
async function createOffer() {
  const pc = new RTCPeerConnection();
  const dc = pc.createDataChannel('chat');
  dc.onmessage = e => console.log('recv', e.data);

  const offer = await pc.createOffer();
  await pc.setLocalDescription(offer);
  // show offer.sdp en UI para copiar
  return { pc, offer: pc.localDescription.sdp };
}

async function receiveOffer(offerSdp) {
  const pc = new RTCPeerConnection();
  pc.ondatachannel = ev => {
    const dc = ev.channel;
    dc.onmessage = e => console.log('recv', e.data);
  };
  const desc = { type: 'offer', sdp: offerSdp };
  await pc.setRemoteDescription(desc);
  const answer = await pc.createAnswer();
  await pc.setLocalDescription(answer);
  // devuelve answer.sdp para que el otro lo pegue
  return { pc, answer: pc.localDescription.sdp };
}

async function finalizeAnswer(pc, answerSdp) {
  await pc.setRemoteDescription({ type: 'answer', sdp: answerSdp });
}

