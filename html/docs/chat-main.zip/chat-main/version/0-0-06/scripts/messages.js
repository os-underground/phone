(function(){
  const toField = document.getElementById('toField');
  const msgInput = document.getElementById('msgInput');
  const sendBtn = document.getElementById('sendMsg');
  const listEl = document.getElementById('msgList');
  const exportBtn = document.getElementById('exportMsgs');

  function render(){
    const msgs = window.AppDB.getData('messages') || [];
    listEl.innerHTML = msgs.slice().reverse().map(m=>(
      '<li><div class="small muted">'+m.time+'</div><div><b>'+escapeHtml(m.to||m.toName||'Para:anon')+'</b></div><div>'+escapeHtml(m.text)+'</div></li>'
    )).join('');
  }

  function escapeHtml(s){ if(!s) return ''; return String(s).replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

  sendBtn.addEventListener('click', function(){
    const to = toField.value.trim();
    const text = msgInput.value.trim();
    if(!to || !text){ alert('Completa destinatario y mensaje'); return; }
    const msgs = window.AppDB.getData('messages') || [];
    msgs.push({ to: to, text: text, time: new Date().toLocaleString() });
    window.AppDB.saveData('messages', msgs);
    msgInput.value='';
    render();
    alert('Mensaje guardado localmente. Para enviarlo a otra persona, exporta/importa o usa WebRTC.');
  });

  exportBtn.addEventListener('click', function(){
    const msgs = window.AppDB.getData('messages') || [];
    window.AppDB.downloadJSON('messages.json', msgs);
  });

  // init
  render();
})();