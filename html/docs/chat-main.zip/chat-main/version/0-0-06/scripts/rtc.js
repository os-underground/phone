// rtc.js — WebRTC copy/paste minimal (no signaling server)
// This file integrates with the UI present in messages.html
(function(window){
  const RTC_CONFIG = { iceServers: [{ urls: "stun:stun.l.google.com:19302" }] };

  function createPeer() {
    const pc = new RTCPeerConnection(RTC_CONFIG);
    pc.onicecandidate = (ev) => {
      console.debug("ICE candidate", ev.candidate);
    };
    return pc;
  }

  async function makeOffer(onDataChannelMessage) {
    const pc = createPeer();
    const dc = pc.createDataChannel("messaging");
    dc.onopen = () => console.debug("DataChannel open");
    dc.onmessage = (e) => { if (onDataChannelMessage) onDataChannelMessage(e.data); };
    const offer = await pc.createOffer();
    await pc.setLocalDescription(offer);
    await waitForIceGathering(pc, 2000);
    return { pc, sdp: pc.localDescription.sdp, send: (msg) => dc.send(msg) };
  }

  async function acceptOffer(offerSdp, onDataChannelMessage) {
    const pc = createPeer();
    pc.ondatachannel = (ev) => {
      const dc = ev.channel;
      dc.onopen = () => console.debug("DataChannel (remote) open");
      dc.onmessage = (e) => { if (onDataChannelMessage) onDataChannelMessage(e.data); };
      pc._send = (m) => dc.send(m);
    };
    await pc.setRemoteDescription({ type: "offer", sdp: offerSdp });
    const answer = await pc.createAnswer();
    await pc.setLocalDescription(answer);
    await waitForIceGathering(pc, 2000);
    return { pc, sdp: pc.localDescription.sdp, send: (m) => pc._send ? pc._send(m) : console.warn("not ready") };
  }

  async function finalizeCaller(pc, answerSdp) {
    await pc.setRemoteDescription({ type: "answer", sdp: answerSdp });
  }

  function waitForIceGathering(pc, ms = 1500) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  window.RTCManual = { makeOffer, acceptOffer, finalizeCaller };
})(window);
