(function(){
  window.AppDB = {
    saveData: function(key, data){
      try {
        localStorage.setItem(key, JSON.stringify(data));
      } catch(e) {
        console.error('saveData error', e);
      }
    },
    getData: function(key){
      try {
        return JSON.parse(localStorage.getItem(key) || 'null');
      } catch(e){ return null; }
    },
    clearAll: function(){
      localStorage.clear();
    },
    downloadJSON: function(filename, obj){
      const blob = new Blob([JSON.stringify(obj, null, 2)], {type:'application/json'});
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      a.click();
      URL.revokeObjectURL(url);
    }
  };
})();