# POLÍTICAS Y CONSIDERACIONES LEGALES — Mi Social v0.0.6

**Resumen:** Esta aplicación es un prototipo local y de código abierto que guarda datos únicamente en el navegador del usuario. No hay servidor central por defecto.

## Privacidad
- Los datos se guardan localmente en el navegador (localStorage/IndexedDB).
- El usuario puede eliminar o exportar sus datos desde Ajustes.
- IndexedDB permite almacenar archivos más grandes que localStorage, pero los límites dependen del navegador.

## Consentimiento
- Obtén consentimiento antes de importar datos de terceros.
- No enviar SMS automáticos sin consentimiento.

## Mensajería P2P
- WebRTC copy/paste permite conexiones directas; no garantiza entrega si los pares están desconectados.
- Para persistencia, se necesita backend.

## Envío de SMS/Notificaciones
- Requiere backend y proveedor (Twilio, etc.). No pongas credenciales en repositorios públicos.
- Alternativa: enlaces sms: o wa.me: para abrir apps del usuario con texto prellenado.

## Menores
- La app solicita confirmación de mayoría de edad; no admite menores sin medidas adicionales.

## Moderación
- Implementa bloqueo y reporte local (se puede exportar evidencia).
- Define un canal privado para recibir reportes del administrador.

**Aviso:** Esto no es asesoría legal. Consulta con un profesional si escalarás el servicio.
