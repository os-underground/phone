# b-i-u-s social — v0.0.8
Versión con escáner QR y finalización automática (pega respuesta).