# POLICIES v0.0.8
Mejoras de UX y escáner QR. Lee POLICIES_LEGALES.md en la carpeta raíz.