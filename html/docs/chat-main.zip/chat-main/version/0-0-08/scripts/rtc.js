(function(window){
  const RTC_CONFIG = { iceServers: [{ urls: "stun:stun.l.google.com:19302" }] };
  function createPeer(){ const pc=new RTCPeerConnection(RTC_CONFIG); pc.onicecandidate=(e)=>console.debug('ice',e.candidate); return pc; }
  async function makeOffer(onMsg,onOpen){ const pc=createPeer(); const dc=pc.createDataChannel('chat'); dc.onopen=()=>{console.debug('dc open'); if(onOpen) onOpen();}; dc.onmessage=(e)=>{ if(onMsg) onMsg(e.data); }; const offer=await pc.createOffer(); await pc.setLocalDescription(offer); await waitForIce(pc,1500); return {pc, sdp: pc.localDescription.sdp, send:(m)=>dc.send(m)}; }
  async function acceptOffer(offerSdp,onMsg,onOpen){ const pc=createPeer(); pc.ondatachannel=(ev)=>{ const dc=ev.channel; dc.onopen=()=>{ console.debug('dc open remote'); if(onOpen) onOpen(); }; dc.onmessage=(e)=>{ if(onMsg) onMsg(e.data); }; pc._send=(m)=>dc.send(m); }; await pc.setRemoteDescription({type:'offer', sdp: offerSdp}); const answer=await pc.createAnswer(); await pc.setLocalDescription(answer); await waitForIce(pc,1500); return {pc, sdp: pc.localDescription.sdp, send:(m)=> pc._send?pc._send(m):console.warn('not ready')}; }
  async function finalizeCaller(pc, answerSdp){ await pc.setRemoteDescription({type:'answer', sdp: answerSdp}); }
  function waitForIce(pc, ms=1500){ return new Promise(r=>setTimeout(r, ms)); }
  window.RTCManual={ makeOffer, acceptOffer, finalizeCaller };
})(window);