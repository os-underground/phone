



export function saveData(key, data) {
  localStorage.setItem(key, JSON.stringify(data));
}

export function getData(key) {
  return JSON.parse(localStorage.getItem(key) || "null");
}

export function clearAll() {
  localStorage.clear();
}
🧍‍♂️ scripts/ui.js — Perfil básico
js
Copiar código
import { saveData, getData, clearAll } from './db.js';

document.getElementById('saveProfile').addEventListener('click', () => {
  const user = {
    name: document.getElementById('username').value,
    bio: document.getElementById('bio').value
  };
  saveData('user', user);
  alert('Perfil guardado');
});

document.getElementById('clearData').addEventListener('click', () => {
  if (confirm('¿Seguro que quieres borrar tus datos?')) {
    clearAll();
    location.reload();
  }
});
    /*
👥 scripts/contacts.js — Importar contactos
💡 El API navigator.contacts solo funciona en navegadores móviles con permisos, así que lo haremos con fallback.

js
Copiar código
*/
                         
document.getElementById('importContacts').addEventListener('click', async () => {
  if ('contacts' in navigator && 'select' in navigator.contacts) {
    try {
      const contacts = await navigator.contacts.select(['name', 'tel'], { multiple: true });
      localStorage.setItem('contacts', JSON.stringify(contacts));
      alert('Contactos importados!');
    } catch {
      alert('No se pudo importar.');
    }
  } else {
    alert('Tu navegador no soporta importación directa. Agrega contactos manualmente.');
  }
});
/*
💬 scripts/messages.js — Mensajería local (simple)
js
Copiar código

*/
import { getData, saveData } from './db.js';

const sendBtn = document.getElementById('sendMsg');
const input = document.getElementById('msgInput');
const list = document.getElementById('msgList');

sendBtn.addEventListener('click', () => {
  const messages = getData('messages') || [];
  const text = input.value.trim();
  if (!text) return;
  messages.push({ text, time: new Date().toLocaleString() });
  saveData('messages', messages);
  renderMessages();
  input.value = '';
});

function renderMessages() {
  const messages = getData('messages') || [];
  list.innerHTML = messages.map(m => `<li>[${m.time}] ${m.text}</li>`).join('');
}

renderMessages();
