# b-i-u-s social — version 0.0.7
Contenido: simplified P2P chat with QR support (UI-friendly).
How to use:
1. Upload folder to GitHub Pages or open index.html in a secure context (https or localhost).
2. Click "Crear invitación" on device A — share QR or copy text.
3. On device B, paste the invitation in "Pega la invitación" and click "Aceptar invitación".
4. B copies the generated "respuesta" and sends it back to A.
5. A pastes that response in the advanced flow (or we rely on manual) and finalizes — then messages flow.

Notes:
- This is a simple manual signaling flow (no TURN server). Some networks may block direct P2P.
- For automation and improved UX, a signalling server or short-lived link service is recommended.
